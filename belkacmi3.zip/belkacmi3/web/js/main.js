$(document).ready( function() {
        $(document).on('change', '.btn-file :file', function() {
        var input = $(this),
            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [label]);
        });

        $('.btn-file :file').on('fileselect', function(event, label) {
            
            var input = $(this).parents('.input-group').find(':text'),
                log = label;
            
            if( input.length ) {
                input.val(log);
            } else {
                if( log ) alert(log);
            }
        
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function (e) {
                    $('#img-upload').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function(){
            readURL(this);
        });     
    });
    
inames = []

iprice = []

function addItem(){
  
  inames.push(document.getElementById('pname').value)
  iprice.push(parseInt(document.getElementById('price').value))
  
  displayCart()
   
}

function displayCart(){
  
  
  cartdata = '<table><tr><th>Product Name</th><th>Price</th><th>Total</th></tr>';
  
  total = 0;
  
  for (i=0; i<inames.length; i++){
    total += iprice[i]
    cartdata += "<tr><td>" + inames[i] + "</td><td>" + iprice[i] + "</td><td><button onclick='delElement(" + i + ")'>Delete</button></td></tr>"
    }
  
  cartdata += '<tr><td></td><td></td><td>' + total + '</td></tr></table>'
  
  document.getElementById('cart').innerHTML = cartdata
  
}


function delElement(a){
  inames.splice(a, 1);
  
  iprice.splice(a, 1)
  displayCart()
}