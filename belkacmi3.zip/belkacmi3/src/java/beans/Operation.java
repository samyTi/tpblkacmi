
package beans;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

public class Operation {
public void ajouterProd(Produit p){
 try {
			//1
			Class.forName("com.mysql.jdbc.Driver");
			//2
			Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/panier","root","");
			//3
			PreparedStatement pr = cn.prepareStatement("INSERT INTO produit  (`libelle`, `photo`, `prix`)  VALUES(?,?,?)");
			pr.setString(1, p.getLibelle());
			pr.setString(2, p.getPath());
			pr.setDouble(3, (double) p.getPrix());
			//4
			pr.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	
} 
public ArrayList<Produit> affichercatalogue() {
		ArrayList<Produit> produits = new ArrayList<Produit>();
		
		try {
			//1
			Class.forName("com.mysql.jdbc.Driver");
			//2
			Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/panier","root","");
			//3
			PreparedStatement pr = cn.prepareStatement("SELECT libelle,photo,prix FROM produit");
			//4
			ResultSet rs = pr.executeQuery();
			//5
			
			while(rs.next()) {
				Produit p = new Produit();
				p.setLibbele(rs.getString("libelle"));
				p.setPath(rs.getString("photo"));
				p.setPrix(rs.getFloat("prix"));
				produits.add(p);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return produits;
	
}
}