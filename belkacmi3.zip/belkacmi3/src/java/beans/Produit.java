/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author samy
 */
public class Produit {
    private String libelle,path;
private double prix;

    public Produit() {
    }

    public Produit(String libbele, String path, double prix) {
        this.libelle = libbele;
        this.path = path;
        this.prix = prix;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getPath() {
        return path;
    }

    public double getPrix() {
        return prix;
    }

    public void setLibbele(String libbele) {
        this.libelle = libbele;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

}
